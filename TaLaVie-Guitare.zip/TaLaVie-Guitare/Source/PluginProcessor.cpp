#include "PluginProcessor.h"

//==============================  VOIX  ==============================
void GuitarVoice::startNote (int midiNote, float velocity, juce::SynthesiserSound*, int)
{
    const double sr   = getSampleRate();
    const float  sus  = apvts.getRawParameterValue ("sustain")->load();      // secondes (-60 dB)
    const float  bri  = apvts.getRawParameterValue ("brightness")->load();   // 0..1
    const float  rel  = apvts.getRawParameterValue ("release")->load();      // secondes
    gain = 0.35f;

    const double freq = juce::MidiMessage::getMidiNoteInHertz (midiNote);

    // Filtre de boucle (passe-bas à 1 pôle) : plus 'a' est petit, plus c'est brillant
    a = juce::jlimit (0.02f, 0.7f, 0.58f - 0.5f * bri - 0.05f * velocity);
    const double lpDelay = a / (1.0 - a);

    // Longueur de boucle = entier + fraction (filtre passe-tout pour l'accord fin)
    const double target = sr / freq - lpDelay;
    delayLen = juce::jmax (2, (int) (target - 0.5));
    const double d = target - delayLen;
    eta = (float) ((1.0 - d) / (1.0 + d));

    // Décroissance : -60 dB en 'sus' secondes
    g = (float) juce::jmin (0.9995, std::pow (0.001, (delayLen + d + lpDelay) / (sr * sus)));

    // Excitation : bruit adouci (ongle/nylon) + effet de position du doigt
    buffer.assign ((size_t) delayLen, 0.f);
    std::vector<float> exc ((size_t) delayLen);
    for (auto& s : exc) s = rng.nextFloat() * 2.f - 1.f;
    for (int pass = 0; pass < 2; ++pass)
    {
        float prev = 0.f;
        for (auto& s : exc) { prev = 0.5f * s + 0.5f * prev; s = prev; }
    }
    const int k = juce::jmax (1, (int) (0.14 * delayLen));
    float mean = 0.f, peak = 1e-9f;
    for (int i = 0; i < delayLen; ++i)
    {
        buffer[(size_t) i] = exc[(size_t) i] - (i >= k ? exc[(size_t) (i - k)] : 0.f);
        mean += buffer[(size_t) i];
    }
    mean /= (float) delayLen;
    for (auto& s : buffer) { s -= mean; peak = juce::jmax (peak, std::abs (s)); }
    const float v = 0.35f + 0.65f * velocity;
    for (auto& s : buffer) s *= v / peak;

    pos = 0; x1 = y1 = lp = 0.f;
    level = 1.f; releasing = false; silentCount = 0;
    relCoef = (float) std::pow (0.001, 1.0 / (sr * rel));
}

void GuitarVoice::stopNote (float, bool allowTailOff)
{
    if (allowTailOff) releasing = true;
    else              clearCurrentNote();
}

void GuitarVoice::renderNextBlock (juce::AudioBuffer<float>& out, int start, int num)
{
    if (! isVoiceActive()) return;

    for (int i = 0; i < num; ++i)
    {
        const float v  = buffer[(size_t) pos];
        const float ap = eta * v + x1 - eta * y1;
        x1 = v; y1 = ap;
        lp = (1.f - a) * ap + a * lp;
        buffer[(size_t) pos] = lp * g;
        if (++pos >= delayLen) pos = 0;

        if (releasing) level *= relCoef;
        const float s = v * level * gain;

        for (int ch = 0; ch < out.getNumChannels(); ++ch)
            out.addSample (ch, start + i, s);

        silentCount = (std::abs (s) < 1.0e-5f) ? silentCount + 1 : 0;
        if (level < 0.001f || silentCount > (int) getSampleRate() / 5)
        {
            clearCurrentNote();
            break;
        }
    }
}

//============================  PROCESSEUR  ===========================
juce::AudioProcessorValueTreeState::ParameterLayout TaLaVieGuitareProcessor::createLayout()
{
    using P = juce::AudioParameterFloat;
    using R = juce::NormalisableRange<float>;
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    p.push_back (std::make_unique<P> ("sustain",    "Sustain (s)",   R (1.f, 20.f, 0.01f, 0.6f), 9.f));
    p.push_back (std::make_unique<P> ("release",    "Release (s)",   R (0.1f, 4.f, 0.01f, 0.6f), 1.2f));
    p.push_back (std::make_unique<P> ("brightness", "Brillance",     R (0.f, 1.f, 0.01f), 0.45f));
    p.push_back (std::make_unique<P> ("body",       "Corps guitare", R (0.f, 1.f, 0.01f), 0.6f));
    p.push_back (std::make_unique<P> ("reverbSize", "Reverb taille", R (0.f, 1.f, 0.01f), 0.7f));
    p.push_back (std::make_unique<P> ("reverbMix",  "Reverb mix",    R (0.f, 1.f, 0.01f), 0.35f));
    p.push_back (std::make_unique<P> ("volume",     "Volume",        R (0.f, 1.5f, 0.01f), 1.0f));
    return { p.begin(), p.end() };
}

TaLaVieGuitareProcessor::TaLaVieGuitareProcessor()
    : AudioProcessor (BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMS", createLayout())
{
    synth.addSound (new GuitarSound());
    for (int i = 0; i < 12; ++i)
        synth.addVoice (new GuitarVoice (apvts));
}

void TaLaVieGuitareProcessor::prepareToPlay (double sr, int)
{
    synth.setCurrentPlaybackSampleRate (sr);
    reverb.setSampleRate (sr);
    reverb.reset();

    const float freqs[3] = { 100.f, 210.f, 480.f };
    const float qs[3]    = { 2.5f, 3.0f, 2.0f };
    for (int ch = 0; ch < 2; ++ch)
        for (int i = 0; i < 3; ++i)
        {
            body[ch][i].coefficients = juce::dsp::IIR::Coefficients<float>::makePeakFilter (sr, freqs[i], qs[i], 1.5f);
            body[ch][i].reset();
        }
}

void TaLaVieGuitareProcessor::processBlock (juce::AudioBuffer<float>& buf, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buf.clear();
    synth.renderNextBlock (buf, midi, 0, buf.getNumSamples());

    const int n = buf.getNumSamples();

    // Corps de la guitare : résonances mélangées selon le réglage
    const float bodyAmt = apvts.getRawParameterValue ("body")->load();
    for (int ch = 0; ch < 2; ++ch)
    {
        auto* d = buf.getWritePointer (ch);
        for (int i = 0; i < n; ++i)
        {
            float s = d[i], r = s;
            for (auto& f : body[ch]) r = f.processSample (r);
            d[i] = s + bodyAmt * (r - s);
        }
    }

    // Reverb intégrée
    const float mix  = apvts.getRawParameterValue ("reverbMix")->load();
    juce::Reverb::Parameters rp;
    rp.roomSize   = apvts.getRawParameterValue ("reverbSize")->load();
    rp.damping    = 0.45f;
    rp.wetLevel   = mix * 0.55f;
    rp.dryLevel   = 1.f - 0.4f * mix;
    rp.width      = 1.f;
    reverb.setParameters (rp);
    reverb.processStereo (buf.getWritePointer (0), buf.getWritePointer (1), n);

    buf.applyGain (apvts.getRawParameterValue ("volume")->load());
}

juce::AudioProcessorEditor* TaLaVieGuitareProcessor::createEditor()
{
    return new juce::GenericAudioProcessorEditor (*this);   // interface simple, on la personnalisera ensuite
}

void TaLaVieGuitareProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary (*xml, dest);
}

void TaLaVieGuitareProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new TaLaVieGuitareProcessor(); }
